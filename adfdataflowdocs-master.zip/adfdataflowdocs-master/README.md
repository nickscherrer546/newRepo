# ADF Mapping Data Flows are now in limited public preview
# The docs in this repo are old and no longer updated

Please see Data Flow documentation under Azure Data Factory docs: https://docs.microsoft.com/en-us/azure/data-factory/data-flow-create 
