sample data for SCD Type 2
