# Azure Data Factory Data Flow Transformations

## Union

Union will combine multiple data streams into one, with the SQL Union of those streams as the new output from the Union transformation.

![Union Transformation](../images/union.png "Union")

